package lv.starstranger;

import lv.starstranger.block.ModBlocks;
import lv.starstranger.item.ModItemGroups;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_11515;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AmazingFlowers implements ModInitializer {
	public static final String MOD_ID = "amazing-flowers";

	// This logger is used to write text to the console and the log file.
	// It is considered best practice to use your mod id as the logger's name.
	// That way, it's clear which mod wrote info, warnings, and errors.
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("-=* Amazing Flowers *=-");


		ModBlocks.initialize();
		ModItemGroups.registerItemGroups();

		if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
			//add block transparency
			BlockRenderLayerMap.putBlock(ModBlocks.COSMIC_FLOWER, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.TARAXACUM, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.BLUEBELLS, class_11515.field_60925);

			BlockRenderLayerMap.putBlock(ModBlocks.ANEMONE_PINK, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.ANEMONE_WHITE, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.ANEMONE_RED, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.ANEMONE_PURPLE, class_11515.field_60925);

			BlockRenderLayerMap.putBlock(ModBlocks.BEGONIA_PINK, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.BEGONIA_WHITE, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.BEGONIA_RED, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.BEGONIA_YELLOW, class_11515.field_60925);

			BlockRenderLayerMap.putBlock(ModBlocks.CROCUS_PINK, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.CROCUS_PURPLE, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.CROCUS_WHITE, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.CROCUS_YELLOW, class_11515.field_60925);

			BlockRenderLayerMap.putBlock(ModBlocks.POTTED_COSMIC_FLOWER, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.POTTED_TARAXACUM, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.POTTED_BLUEBELLS, class_11515.field_60925);

			BlockRenderLayerMap.putBlock(ModBlocks.POTTED_ANEMONE_PINK, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.POTTED_ANEMONE_PURPLE, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.POTTED_ANEMONE_RED, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.POTTED_ANEMONE_WHITE, class_11515.field_60925);

			BlockRenderLayerMap.putBlock(ModBlocks.POTTED_BEGONIA_PINK, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.POTTED_BEGONIA_RED, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.POTTED_BEGONIA_WHITE, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.POTTED_BEGONIA_YELLOW, class_11515.field_60925);

			BlockRenderLayerMap.putBlock(ModBlocks.DIGITALIS_PURPUREA_RUBY, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.DIGITALIS_PURPUREA_PURPLE, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.DELPHINIUM, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.JOE_PYE_WEED, class_11515.field_60925);

			BlockRenderLayerMap.putBlock(ModBlocks.WHITEROSE_BUSH, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.YELLOWROSE_BUSH, class_11515.field_60925);
			BlockRenderLayerMap.putBlock(ModBlocks.PURPLEROSE_BUSH, class_11515.field_60925);
		}



	}

}