package lv.starstranger.item;

import lv.starstranger.AmazingFlowers;
import lv.starstranger.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModItemGroups {
    // 1. Define the Registry Key
    public static final class_5321<class_1761> AMAZING_FLOWERS_KEY = class_5321.method_29179(
            class_7924.field_44688,
            class_2960.method_60655(AmazingFlowers.MOD_ID, "amazing_flowers")
    );

    // 2. Build and Register the ItemGroup
    public static final class_1761 AMAZING_FLOWERS = class_2378.method_39197(
            class_7923.field_44687,
            AMAZING_FLOWERS_KEY,
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemGroup.your_mod_id.amazing_flowers"))
                    .method_47320(() -> new class_1799(ModBlocks.JOE_PYE_WEED.method_8389())) // Set your icon here
                    .method_47317((displayContext, itemGroup) -> {
                        //entries.add(Items.POPPY); // Add items to the group
                        itemGroup.method_45421(ModBlocks.COSMIC_FLOWER.method_8389());

                        itemGroup.method_45421(ModBlocks.TARAXACUM.method_8389());
                        itemGroup.method_45421(ModBlocks.BLUEBELLS.method_8389());
                        itemGroup.method_45421(ModBlocks.ANEMONE_PINK.method_8389());
                        itemGroup.method_45421(ModBlocks.ANEMONE_RED.method_8389());
                        itemGroup.method_45421(ModBlocks.ANEMONE_WHITE.method_8389());
                        itemGroup.method_45421(ModBlocks.ANEMONE_PURPLE.method_8389());
                        itemGroup.method_45421(ModBlocks.BEGONIA_PINK.method_8389());
                        itemGroup.method_45421(ModBlocks.BEGONIA_RED.method_8389());
                        itemGroup.method_45421(ModBlocks.BEGONIA_WHITE.method_8389());
                        itemGroup.method_45421(ModBlocks.BEGONIA_YELLOW.method_8389());
                        itemGroup.method_45421(ModBlocks.CROCUS_WHITE.method_8389());
                        itemGroup.method_45421(ModBlocks.CROCUS_YELLOW.method_8389());
                        itemGroup.method_45421(ModBlocks.CROCUS_PINK.method_8389());
                        itemGroup.method_45421(ModBlocks.CROCUS_PURPLE.method_8389());
                        itemGroup.method_45421(ModBlocks.DIGITALIS_PURPUREA_RUBY.method_8389());
                        itemGroup.method_45421(ModBlocks.DIGITALIS_PURPUREA_PURPLE.method_8389());
                        itemGroup.method_45421(ModBlocks.DELPHINIUM.method_8389());
                        itemGroup.method_45421(ModBlocks.JOE_PYE_WEED.method_8389());
                        itemGroup.method_45421(ModBlocks.WHITEROSE_BUSH.method_8389());
                        itemGroup.method_45421(ModBlocks.YELLOWROSE_BUSH.method_8389());
                        itemGroup.method_45421(ModBlocks.PURPLEROSE_BUSH.method_8389());

                        itemGroup.method_45421(ModBlocks.POTTED_COSMIC_FLOWER.method_8389());
                        itemGroup.method_45421(ModBlocks.POTTED_TARAXACUM.method_8389());
                        itemGroup.method_45421(ModBlocks.POTTED_BLUEBELLS.method_8389());

                        itemGroup.method_45421(ModBlocks.POTTED_ANEMONE_PINK.method_8389());
                        itemGroup.method_45421(ModBlocks.POTTED_ANEMONE_WHITE.method_8389());
                        itemGroup.method_45421(ModBlocks.POTTED_ANEMONE_RED.method_8389());
                        itemGroup.method_45421(ModBlocks.POTTED_ANEMONE_PURPLE.method_8389());

                        itemGroup.method_45421(ModBlocks.POTTED_BEGONIA_PINK.method_8389());
                        itemGroup.method_45421(ModBlocks.POTTED_BEGONIA_RED.method_8389());
                        itemGroup.method_45421(ModBlocks.POTTED_BEGONIA_WHITE.method_8389());
                        itemGroup.method_45421(ModBlocks.POTTED_BEGONIA_YELLOW.method_8389());
                    })
                    .method_47324()
    );

    public static void registerItemGroups() {
        
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40743).register((itemGroup) -> {
            itemGroup.method_45421(ModBlocks.COSMIC_FLOWER.method_8389());
            itemGroup.method_45421(ModBlocks.TARAXACUM.method_8389());
            itemGroup.method_45421(ModBlocks.BLUEBELLS.method_8389());
            itemGroup.method_45421(ModBlocks.ANEMONE_PINK.method_8389());
            itemGroup.method_45421(ModBlocks.ANEMONE_RED.method_8389());
            itemGroup.method_45421(ModBlocks.ANEMONE_WHITE.method_8389());
            itemGroup.method_45421(ModBlocks.ANEMONE_PURPLE.method_8389());
            itemGroup.method_45421(ModBlocks.BEGONIA_PINK.method_8389());
            itemGroup.method_45421(ModBlocks.BEGONIA_RED.method_8389());
            itemGroup.method_45421(ModBlocks.BEGONIA_WHITE.method_8389());
            itemGroup.method_45421(ModBlocks.BEGONIA_YELLOW.method_8389());
            itemGroup.method_45421(ModBlocks.CROCUS_WHITE.method_8389());
            itemGroup.method_45421(ModBlocks.CROCUS_YELLOW.method_8389());
            itemGroup.method_45421(ModBlocks.CROCUS_PINK.method_8389());
            itemGroup.method_45421(ModBlocks.CROCUS_PURPLE.method_8389());
            itemGroup.method_45421(ModBlocks.DIGITALIS_PURPUREA_RUBY.method_8389());
            itemGroup.method_45421(ModBlocks.DIGITALIS_PURPUREA_PURPLE.method_8389());
            itemGroup.method_45421(ModBlocks.DELPHINIUM.method_8389());
            itemGroup.method_45421(ModBlocks.JOE_PYE_WEED.method_8389());
            itemGroup.method_45421(ModBlocks.WHITEROSE_BUSH.method_8389());
            itemGroup.method_45421(ModBlocks.YELLOWROSE_BUSH.method_8389());
            itemGroup.method_45421(ModBlocks.PURPLEROSE_BUSH.method_8389());
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register((itemGroup) -> {
            itemGroup.method_45421(ModBlocks.POTTED_COSMIC_FLOWER.method_8389());
            itemGroup.method_45421(ModBlocks.POTTED_TARAXACUM.method_8389());
            itemGroup.method_45421(ModBlocks.POTTED_BLUEBELLS.method_8389());

            itemGroup.method_45421(ModBlocks.POTTED_ANEMONE_PINK.method_8389());
            itemGroup.method_45421(ModBlocks.POTTED_ANEMONE_WHITE.method_8389());
            itemGroup.method_45421(ModBlocks.POTTED_ANEMONE_RED.method_8389());
            itemGroup.method_45421(ModBlocks.POTTED_ANEMONE_PURPLE.method_8389());

            itemGroup.method_45421(ModBlocks.POTTED_ANEMONE_PINK.method_8389());
            itemGroup.method_45421(ModBlocks.POTTED_ANEMONE_WHITE.method_8389());
            itemGroup.method_45421(ModBlocks.POTTED_ANEMONE_RED.method_8389());
            itemGroup.method_45421(ModBlocks.POTTED_ANEMONE_PURPLE.method_8389());
        });
    }
}
