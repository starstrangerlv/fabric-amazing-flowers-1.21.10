package lv.starstranger.block;

import lv.starstranger.AmazingFlowers;
import lv.starstranger.item.ModItemGroups;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.*;
import net.minecraft.class_1294;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2356;
import net.minecraft.class_2362;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2521;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.item.*;
import java.util.function.Function;

public class ModBlocks {
    private static int blockNum = 0;

    public static void initialize() {


    }

    public static final class_2248 COSMIC_FLOWER = register("cosmic_flower",
            settings -> new class_2356(class_1294.field_5924, 10, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_25706)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 TARAXACUM = register("taraxacum",
            settings -> new class_2356(class_1294.field_5924, 10, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15986)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 BLUEBELLS = register("bluebells",
            settings -> new class_2356(class_1294.field_5905, 10, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16016)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 ANEMONE_PINK = register("anemone_pink",
            settings -> new class_2356(class_1294.field_5898, 15, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16016)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 ANEMONE_WHITE = register("anemone_white",
            settings -> new class_2356(class_1294.field_5898, 15, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16016)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 ANEMONE_RED = register("anemone_red",
            settings -> new class_2356(class_1294.field_5898, 15, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16012)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 ANEMONE_PURPLE = register("anemone_purple",
            settings -> new class_2356(class_1294.field_5898, 15, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16016)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 BEGONIA_PINK = register("begonia_pink",
            settings -> new class_2356(class_1294.field_16595, 15, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15989)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 BEGONIA_RED = register("begonia_red",
            settings -> new class_2356(class_1294.field_16595, 15, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15982)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 BEGONIA_WHITE = register("begonia_white",
            settings -> new class_2356(class_1294.field_16595, 15, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16003)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 BEGONIA_YELLOW = register("begonia_yellow",
            settings -> new class_2356(class_1294.field_16595, 15, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16013)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 CROCUS_PINK = register("crocus_pink",
            settings -> new class_2356(class_1294.field_50120, 15, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16016)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 CROCUS_PURPLE = register("crocus_purple",
            settings -> new class_2356(class_1294.field_50120, 15, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16016)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 CROCUS_WHITE = register("crocus_white",
            settings -> new class_2356(class_1294.field_50120, 15, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16025)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 CROCUS_YELLOW = register("crocus_yellow",
            settings -> new class_2356(class_1294.field_50120, 15, settings),
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15986)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971), true);

    public static final class_2248 POTTED_COSMIC_FLOWER = register("potted_cosmic_flower",
            settings -> new class_2362(COSMIC_FLOWER, settings),
            class_4970.class_2251.method_9637(), true);

    public static final class_2248 POTTED_TARAXACUM = register("potted_taraxacum",
            settings -> new class_2362(TARAXACUM, settings),
            class_4970.class_2251.method_9637(), true);

    public static final class_2248 POTTED_BLUEBELLS = register("potted_bluebells",
            settings -> new class_2362(BLUEBELLS, settings),
            class_4970.class_2251.method_9637(), true);



    public static final class_2248 POTTED_ANEMONE_PINK = register("potted_anemone_pink",
            settings -> new class_2362(ANEMONE_PINK, settings),
            class_4970.class_2251.method_9637(), true);

    public static final class_2248 POTTED_ANEMONE_WHITE = register("potted_anemone_white",
            settings -> new class_2362(ANEMONE_WHITE, settings),
            class_4970.class_2251.method_9637(), true);

    public static final class_2248 POTTED_ANEMONE_RED = register("potted_anemone_red",
            settings -> new class_2362(ANEMONE_RED, settings),
            class_4970.class_2251.method_9637(), true);

    public static final class_2248 POTTED_ANEMONE_PURPLE = register("potted_anemone_purple",
            settings -> new class_2362(ANEMONE_PURPLE, settings),
            class_4970.class_2251.method_9637(), true);

    public static final class_2248 POTTED_BEGONIA_PINK = register("potted_begonia_pink",
            settings -> new class_2362(BEGONIA_PINK, settings),
            class_4970.class_2251.method_9637(), true);

    public static final class_2248 POTTED_BEGONIA_RED = register("potted_begonia_red",
            settings -> new class_2362(BEGONIA_RED, settings),
            class_4970.class_2251.method_9637(), true);

    public static final class_2248 POTTED_BEGONIA_WHITE = register("potted_begonia_white",
            settings -> new class_2362(BEGONIA_WHITE, settings),
            class_4970.class_2251.method_9637(), true);

    public static final class_2248 POTTED_BEGONIA_YELLOW = register("potted_begonia_yellow",
            settings -> new class_2362(BEGONIA_YELLOW, settings),
            class_4970.class_2251.method_9637(), true);




    public static final class_2248 DIGITALIS_PURPUREA_RUBY = register("digitalis_purpurea_ruby",
            class_2521::new,
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16012)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50013()
                    .method_50012(class_3619.field_15971), true
    );

    public static final class_2248 DIGITALIS_PURPUREA_PURPLE = register("digitalis_purpurea_purple",
            class_2521::new,
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16016)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50013()
                    .method_50012(class_3619.field_15971), true
    );

    //delphinium
    public static final class_2248 DELPHINIUM = register("delphinium",
            class_2521::new,
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16004)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50013()
                    .method_50012(class_3619.field_15971), true
    );

    //joe_pye_weed
    public static final class_2248 JOE_PYE_WEED = register("joe_pye_weed",
            class_2521::new,
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_25703)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50013()
                    .method_50012(class_3619.field_15971), true
    );

    public static final class_2248 WHITEROSE_BUSH = register("whiterose_bush",
            class_2521::new,
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15993)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50013()
                    .method_50012(class_3619.field_15971), true
    );

    public static final class_2248 YELLOWROSE_BUSH = register("yellowrose_bush",
            class_2521::new,
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15986)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50013()
                    .method_50012(class_3619.field_15971), true
    );

    public static final class_2248 PURPLEROSE_BUSH = register("purplerose_bush",
            class_2521::new,
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16016)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50013()
                    .method_50012(class_3619.field_15971), true
    );






    private static class_2248 register(String name, Function<class_4970.class_2251, class_2248> blockFactory, class_4970.class_2251 settings, boolean shouldRegisterItem) {
        // Create a registry key for the block
        class_5321<class_2248> blockKey = keyOfBlock(name);
        // Create the block instance
        class_2248 block = blockFactory.apply(settings.method_63500(blockKey));

        // Sometimes, you may not want to register an item for the block.
        // Eg: if it's a technical block like `minecraft:moving_piston` or `minecraft:end_gateway`
        if (shouldRegisterItem) {
            // Items need to be registered with a different type of registry key, but the ID
            // can be the same.
            class_5321<class_1792> itemKey = keyOfItem(name);

            class_1747 blockItem = new class_1747(block, new class_1792.class_1793().method_63686(itemKey).method_63685());
            class_2378.method_39197(class_7923.field_41178, itemKey, blockItem);
        }
        blockNum++;
        AmazingFlowers.LOGGER.info("  + block: (" + blockNum + ") " + name);
        return class_2378.method_39197(class_7923.field_41175, blockKey, block);
    }

    private static class_5321<class_2248> keyOfBlock(String name) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(AmazingFlowers.MOD_ID, name));
    }

    private static class_5321<class_1792> keyOfItem(String name) {
        return class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(AmazingFlowers.MOD_ID, name));
    }
}
